package com.cg.test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class AlertBoxzzz {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/168361_Tharani/AlertBoxDemos.html");
        Thread.sleep(5000);
        //--------------this is for alert box--------------------------------------------------
        driver.findElement(By.id("alert")).click();
        Thread.sleep(5000);
        Alert alert=driver.switchTo().alert();
        System.out.println("The alert message is: "+alert.getText());
        alert.accept();
        Thread.sleep(5000);
        //------------------------this is for confirm box---------------------------------------
        driver.findElement(By.id("confirm")).click();
        Thread.sleep(5000);
        Alert confirm=driver.switchTo().alert();
        confirm.accept();
        Thread.sleep(5000);
        driver.findElement(By.id("confirm")).click();
        confirm=driver.switchTo().alert();
        Thread.sleep(5000);
        confirm.dismiss();
        Thread.sleep(5000);
        //------------------------this is for prompt box----------------------------------------
        driver.findElement(By.id("prompt")).click();
        Thread.sleep(5000);
        Alert prompt=driver.switchTo().alert();
        System.out.println("The prompt message is: "+prompt.getText());
        prompt.sendKeys("Gopika");
        Thread.sleep(5000);
        prompt.accept();
        Thread.sleep(5000);
        driver.findElement(By.id("prompt")).click();
        Thread.sleep(5000);
        prompt=driver.switchTo().alert();
        prompt.dismiss();
        Thread.sleep(5000);
        driver.quit();
}}
